package com.ibm.takehome.dao;

import java.util.HashMap;
import java.util.Map;

import com.ibm.takehome.bean.Product;

public class ProductDAO {
	private static Map<Integer , Product>products=new HashMap<Integer , Product>();
	
	Product getProductDetails(String productcode) {
		return null;
		
	}
}
