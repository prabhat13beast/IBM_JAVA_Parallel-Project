package com.ibm.takehome.service;

public class ProductService {

//validate method
	public boolean validateDetails(String in, Integer in1) {
		try {
			if (in.length() == 4) {
				if (in1 > 0)
					return true;
				else {
					System.out.println("quantity should be greater than zero");
					return false;
				}

			} else
				System.out.println("product code should be 4 digit");
		} catch (Exception e) {
			System.out.println("some issues" + e);
		}
		return false;

	}
}
