package com.ibm.takehome.bean;

public class Product {

	private int productcode;
	private String product_name;
	private String product_category;
	private int price;

	public Product(int productcode, String product_name, String product_category, int price) {
		this.productcode = productcode;
		this.product_name = product_name;
		this.product_category = product_category;
		this.price = price;
	}

	public int getProductcode() {
		return productcode;
	}

	public void setProductcode(int productcode) {
		this.productcode = productcode;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_category() {
		return product_category;
	}

	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}
