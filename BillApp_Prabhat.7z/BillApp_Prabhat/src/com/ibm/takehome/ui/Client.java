package com.ibm.takehome.ui;

import java.util.Scanner;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.service.ProductService;

//class for displaying menu to the cashier
public class Client {
	public static void main(String[] args) {
		int exit = 0;
		int choice;
		Product prod = null;
		Scanner sc = new Scanner(System.in);
		ProductService service = new ProductService();
		while (exit == 0) {
			System.out.println("Enter choice of operation you want to perform");
			System.out.println("1.Generate Bill by entering Product code and quantity \n" + "2. Exit");
			choice = sc.nextInt();
			sc.nextLine();
			switch (choice) {
			case 1:
				System.out.println("enter product details:-");
				System.out.println("enter the product code:");
				Scanner s = new Scanner(System.in);
				String in = s.nextLine();
				System.out.println("enter the quantity:");
				Integer in1 = s.nextInt();

				if (service.validateDetails(in, in1)) {
				//	if (in.equals(Integer.getInteger(products))) {

					}

				//}
			case 2:
				exit = 1;
				System.out.println("app exit...");
				break;

			default:
				System.out.println("enter right choice");
			}
		}
	}
}
